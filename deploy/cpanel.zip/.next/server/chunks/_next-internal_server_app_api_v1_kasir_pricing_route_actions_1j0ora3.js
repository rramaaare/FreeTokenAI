module.exports=[8447,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_kasir_pricing_route_actions_1j0ora3.js.map