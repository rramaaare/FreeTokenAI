module.exports=[50525,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_receipts_lookup_route_actions_0zftvrg.js.map