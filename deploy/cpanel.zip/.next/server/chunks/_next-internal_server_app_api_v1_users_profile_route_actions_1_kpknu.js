module.exports=[91724,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_users_profile_route_actions_1_kpknu.js.map