module.exports=[95488,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_providers_route_actions_0g-fca8.js.map