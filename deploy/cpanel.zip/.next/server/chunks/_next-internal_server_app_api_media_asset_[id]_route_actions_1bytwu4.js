module.exports=[6627,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_media_asset_%5Bid%5D_route_actions_1bytwu4.js.map