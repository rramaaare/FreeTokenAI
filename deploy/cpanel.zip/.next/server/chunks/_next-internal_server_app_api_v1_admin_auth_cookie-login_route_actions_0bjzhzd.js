module.exports=[69400,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_auth_cookie-login_route_actions_0bjzhzd.js.map