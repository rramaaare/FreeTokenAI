module.exports=[59149,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_providers_%5Bid%5D_test_route_actions_1il8r_b.js.map