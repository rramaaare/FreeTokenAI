module.exports=[81927,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_generations_route_actions_0nf_tg0.js.map