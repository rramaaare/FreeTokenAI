module.exports=[60265,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_cafes_route_actions_1vst9-b.js.map