module.exports=[1565,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_models_%5Bid%5D_route_actions_02w4a5-.js.map