module.exports=[3640,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_generations_%5Bid%5D_route_actions_0czhss4.js.map