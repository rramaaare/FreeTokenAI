module.exports=[68549,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_cafes_%5Bid%5D_balance_route_actions_1ggx893.js.map