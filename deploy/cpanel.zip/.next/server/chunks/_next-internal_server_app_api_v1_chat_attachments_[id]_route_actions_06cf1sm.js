module.exports=[73245,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_chat_attachments_%5Bid%5D_route_actions_06cf1sm.js.map