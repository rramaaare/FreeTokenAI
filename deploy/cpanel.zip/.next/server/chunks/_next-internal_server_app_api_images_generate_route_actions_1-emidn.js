module.exports=[30635,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_images_generate_route_actions_1-emidn.js.map