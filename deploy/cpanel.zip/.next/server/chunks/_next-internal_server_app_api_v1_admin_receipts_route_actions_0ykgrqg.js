module.exports=[71847,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_receipts_route_actions_0ykgrqg.js.map