module.exports=[7615,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_rbac_route_actions_161jj16.js.map