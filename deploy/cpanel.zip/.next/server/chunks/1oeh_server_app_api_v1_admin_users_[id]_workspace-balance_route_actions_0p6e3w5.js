module.exports=[5097,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_v1_admin_users_%5Bid%5D_workspace-balance_route_actions_0p6e3w5.js.map