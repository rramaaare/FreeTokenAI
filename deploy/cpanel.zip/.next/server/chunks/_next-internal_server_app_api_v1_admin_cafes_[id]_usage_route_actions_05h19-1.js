module.exports=[28652,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_cafes_%5Bid%5D_usage_route_actions_05h19-1.js.map