module.exports=[830,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_usage-logs_%5Bid%5D_rating_route_actions_1tmn7l2.js.map