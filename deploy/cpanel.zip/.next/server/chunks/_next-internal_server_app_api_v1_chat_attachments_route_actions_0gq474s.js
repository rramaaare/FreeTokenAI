module.exports=[41129,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_chat_attachments_route_actions_0gq474s.js.map