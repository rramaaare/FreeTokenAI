module.exports=[22506,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_models_route_actions_1al8ltn.js.map