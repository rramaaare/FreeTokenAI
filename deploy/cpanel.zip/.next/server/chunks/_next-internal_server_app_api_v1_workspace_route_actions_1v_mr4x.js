module.exports=[57286,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_workspace_route_actions_1v_mr4x.js.map