module.exports=[39233,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_healthz_route_actions_15-b67g.js.map