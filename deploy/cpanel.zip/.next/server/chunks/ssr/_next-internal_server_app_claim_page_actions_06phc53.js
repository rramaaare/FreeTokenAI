module.exports=[90321,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_claim_page_actions_06phc53.js.map