module.exports=[76094,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28kasir%29_kasir_status_page_actions_085vz96.js.map