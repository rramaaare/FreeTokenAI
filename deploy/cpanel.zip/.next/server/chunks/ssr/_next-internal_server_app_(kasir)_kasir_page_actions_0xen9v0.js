module.exports=[88310,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28kasir%29_kasir_page_actions_0xen9v0.js.map