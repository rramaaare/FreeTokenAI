module.exports=[98429,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("div",{className:"page-enter flex min-h-0 min-w-0 flex-1",children:a})}])},9288,function(a){a.n(a.i(98429))}];

//# sourceMappingURL=app_dashboard_template_tsx_0qj6xg4._.js.map