module.exports=[73796,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28console%29_cafes_%5Bid%5D_page_actions_1x6oo_e.js.map