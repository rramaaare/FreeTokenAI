module.exports=[78518,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_image_page_actions_0gzmvhw.js.map