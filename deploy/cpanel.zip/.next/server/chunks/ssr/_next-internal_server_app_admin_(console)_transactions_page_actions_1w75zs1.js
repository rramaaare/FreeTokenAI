module.exports=[32850,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28console%29_transactions_page_actions_1w75zs1.js.map