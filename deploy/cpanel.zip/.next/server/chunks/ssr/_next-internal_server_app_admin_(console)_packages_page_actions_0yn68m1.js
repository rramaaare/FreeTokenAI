module.exports=[60079,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28console%29_packages_page_actions_0yn68m1.js.map