module.exports=[62891,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28console%29_rbac_page_actions_0dw20xt.js.map