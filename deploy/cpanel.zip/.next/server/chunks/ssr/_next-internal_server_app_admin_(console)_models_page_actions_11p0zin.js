module.exports=[79877,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28console%29_models_page_actions_11p0zin.js.map