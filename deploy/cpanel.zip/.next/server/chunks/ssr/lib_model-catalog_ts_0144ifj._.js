module.exports=[53453,a=>{a.v(b=>Promise.all(["server/chunks/ssr/lib_model-catalog_ts_1d-dcx8._.js"].map(b=>a.l(b))).then(()=>b(37670)))}];

//# sourceMappingURL=lib_model-catalog_ts_0144ifj._.js.map