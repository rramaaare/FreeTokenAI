module.exports=[73578,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_videos_generate_route_actions_0ebyeyx.js.map