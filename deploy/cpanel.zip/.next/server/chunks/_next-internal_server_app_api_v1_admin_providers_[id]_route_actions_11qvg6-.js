module.exports=[26508,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_providers_%5Bid%5D_route_actions_11qvg6-.js.map