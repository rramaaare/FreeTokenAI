module.exports=[39504,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_token-packages_route_actions_0a9fon5.js.map