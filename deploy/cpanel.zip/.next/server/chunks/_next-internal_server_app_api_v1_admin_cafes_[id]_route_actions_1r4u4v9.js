module.exports=[77752,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_cafes_%5Bid%5D_route_actions_1r4u4v9.js.map