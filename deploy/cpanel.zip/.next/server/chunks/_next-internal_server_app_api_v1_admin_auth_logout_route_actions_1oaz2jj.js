module.exports=[73925,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_auth_logout_route_actions_1oaz2jj.js.map