module.exports=[49719,(e,t,a)=>{t.exports=e.x("assert",()=>require("assert"))},874,(e,t,a)=>{t.exports=e.x("buffer",()=>require("buffer"))},54799,(e,t,a)=>{t.exports=e.x("crypto",()=>require("crypto"))},27699,(e,t,a)=>{t.exports=e.x("events",()=>require("events"))},22734,(e,t,a)=>{t.exports=e.x("fs",()=>require("fs"))},4446,(e,t,a)=>{t.exports=e.x("net",()=>require("net"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},20635,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/action-async-storage.external.js",()=>require("next/dist/server/app-render/action-async-storage.external.js"))},24725,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},59043,(e,t,a)=>{t.exports=e.x("next/dist/server/runtime-reacts.external.js",()=>require("next/dist/server/runtime-reacts.external.js"))},93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},66680,(e,t,a)=>{t.exports=e.x("node:crypto",()=>require("node:crypto"))},81111,(e,t,a)=>{t.exports=e.x("node:stream",()=>require("node:stream"))},46786,(e,t,a)=>{t.exports=e.x("os",()=>require("os"))},14747,(e,t,a)=>{t.exports=e.x("path",()=>require("path"))},60438,(e,t,a)=>{t.exports=e.x("perf_hooks",()=>require("perf_hooks"))},88947,(e,t,a)=>{t.exports=e.x("stream",()=>require("stream"))},55004,(e,t,a)=>{t.exports=e.x("tls",()=>require("tls"))},24361,(e,t,a)=>{t.exports=e.x("util",()=>require("util"))},19299,e=>{"use strict";var t=e.i(66680),a=e.i(89171),r=e.i(62294),n=e.i(40766),i=e.i(68105);class s extends Error{balance;expired=!1;constructor(e){super("Saldo Token tidak cukup."),this.balance=e}}class o extends s{expired=!0;constructor(e){super(e),this.message="Masa aktif workspace habis."}}function d(e,t="id"){return e.expired?"en"===t?`Your workspace has expired (${e.balance} Tokens left). Claim a new receipt to reactivate it.`:`Masa aktif workspace habis (sisa ${e.balance} Token). Klaim struk baru untuk mengaktifkan lagi.`:"en"===t?`Not enough Tokens (balance ${e.balance}). Claim a receipt first.`:`Saldo Token tidak cukup (sisa ${e.balance}). Klaim struk dulu.`}async function c(e){let t=await r.sql`
    SELECT token_balance, (expires_at IS NOT NULL AND expires_at <= now()) AS expired
    FROM workspaces WHERE id = ${e}`,a=t[0]?.token_balance??0;if(t[0]?.expired)throw new o(a);return a}async function u(e){try{return new s(await c(e))}catch(e){if(e instanceof s)return e;throw e}}async function l(e,t){return await r.sql.begin(async a=>{let r=await a`
      UPDATE workspaces SET token_balance = token_balance - ${t}
      WHERE id = ${e} AND token_balance >= ${t}
        AND (expires_at IS NULL OR expires_at > now())
      RETURNING token_balance`;if(!r[0])return null;let n=await a`
      INSERT INTO token_transactions (workspace_id, type, amount, balance_after)
      VALUES (${e}, 'burn', ${-t}, ${r[0].token_balance})
      RETURNING id`;return{balance:r[0].token_balance,ledgerId:n[0].id}})}async function p(e,t,a){if(t){let a=await e`
      SELECT cafe_id FROM workspaces WHERE id = ${t} LIMIT 1`;if(a[0]?.cafe_id)return a[0].cafe_id}if(a){let t=await e`
      SELECT cafe_id FROM api_keys WHERE id = ${a} LIMIT 1`;return t[0]?.cafe_id??null}return null}async function _(e,t,a,r){a?await e`
      UPDATE api_keys SET tokens_used = GREATEST(tokens_used + ${r}, 0),
        last_used_at = CASE WHEN ${r} > 0 THEN now() ELSE last_used_at END
      WHERE id = ${a}`:t&&await e`
      UPDATE api_keys SET tokens_used = GREATEST(tokens_used + ${r}, 0),
        last_used_at = CASE WHEN ${r} > 0 THEN now() ELSE last_used_at END
      WHERE workspace_id = ${t} AND is_active = TRUE AND revoked_at IS NULL`}async function w(e,t,a,n){await r.sql.begin(async r=>{let i=await p(r,e,a.apiKeyId??null),s=await r`
      INSERT INTO usage_logs (workspace_id, api_key_id, cafe_id, model_id, tokens_burned, endpoint_type, status, media_url)
      VALUES (${e}, ${a.apiKeyId??null}, ${i}, ${a.modelId}, ${t}, ${a.endpointType}, 'success', ${a.mediaUrl??null})
      RETURNING id`;await r`
      UPDATE token_transactions SET reference_type = 'usage_log', reference_id = ${s[0].id}
      WHERE id = ${n}`,await _(r,e,a.apiKeyId??null,t),a.onUsageLogged?.(s[0].id)})}async function k(e,t,a,n){return r.sql.begin(async r=>{let i=await r`
      UPDATE workspaces SET token_balance = token_balance + ${t}
      WHERE id = ${e} RETURNING token_balance`,s=i[0]?.token_balance??0,o=await p(r,e,a.apiKeyId??null),d=await r`
      INSERT INTO usage_logs (workspace_id, api_key_id, cafe_id, model_id, tokens_burned, endpoint_type, status, media_url)
      VALUES (${e}, ${a.apiKeyId??null}, ${o}, ${a.modelId}, ${t}, ${a.endpointType}, 'refunded', ${a.mediaUrl??null})
      RETURNING id`;return await _(r,e,a.apiKeyId??null,-t),await r`
      INSERT INTO token_transactions (workspace_id, type, amount, balance_after, reference_type, reference_id)
      VALUES (${e}, 'refund', ${t}, ${s}, 'usage_log', ${d[0].id})`,await r`
      UPDATE token_transactions SET reference_type = 'usage_log', reference_id = ${d[0].id}
      WHERE id = ${n}`,s})}async function E(e,t,a,r){let i,s=Math.max(1,Math.ceil(t*(r.units??1)));await c(e);let o=await l(e,s);if(!o)throw await u(e);let d=(0,n.newRequestId)(),p=Date.now(),_=(t,a,i)=>(0,n.logReq)({reqId:d,workspaceId:e,endpoint:r.endpointType,latencyMs:Date.now()-p,status:t,ok:a,note:i});try{i=await a()}catch(t){throw await k(e,s,r,o.ledgerId),_(500,!1,"throw->refund"),t}return i.ok||402===i.status?(await w(e,s,r,o.ledgerId),_(i.status,!0)):(await k(e,s,r,o.ledgerId),_(i.status,!1,"fail->refund")),i}class f extends Error{remaining;constructor(e){super("Kuota API key tidak cukup."),this.remaining=e}}async function x(e){let t=await r.sql`
    SELECT GREATEST(token_quota - tokens_used, 0)::int AS remaining
    FROM api_keys WHERE id = ${e}`;return t[0]?.remaining??0}async function T(e,t,a,i,s){let o,d=Math.max(1,Math.ceil(a*(s.units??1)));if(!(await r.sql`
    UPDATE api_keys SET tokens_used = tokens_used + ${d}, last_used_at = now()
    WHERE id = ${e} AND is_active = TRUE AND revoked_at IS NULL
      AND (expires_at IS NULL OR expires_at > now())
      AND tokens_used + ${d} <= token_quota
    RETURNING tokens_used`)[0])throw new f(await x(e));let c=(0,n.newRequestId)(),u=Date.now(),l=(e,t,a)=>(0,n.logReq)({reqId:c,workspaceId:null,endpoint:s.endpointType,latencyMs:Date.now()-u,status:e,ok:t,note:a}),p=async(a,n)=>{0!==n&&await r.sql`UPDATE api_keys SET tokens_used = GREATEST(tokens_used + ${n}, 0) WHERE id = ${e}`,await r.sql`
      INSERT INTO usage_logs (workspace_id, api_key_id, cafe_id, model_id, tokens_burned, endpoint_type, status, media_url)
      VALUES (NULL, ${e}, ${t}, ${s.modelId}, ${d}, ${s.endpointType}, ${a}, ${s.mediaUrl??null})`};try{o=await i()}catch(e){throw await p("refunded",-d),l(500,!1,"throw->refund"),e}return o.ok||402===o.status?(await p("success",0),l(o.status,!0)):(await p("refunded",-d),l(o.status,!1,"fail->refund")),o}async function y(e){let a=(0,t.createHash)("sha256").update(e).digest("hex");return(await r.sql`
    SELECT ak.id, ak.workspace_id, ak.cafe_id FROM api_keys ak
    WHERE ak.key_hash = ${a} AND ak.is_active = TRUE
      AND ak.revoked_at IS NULL
      AND (ak.expires_at IS NULL OR ak.expires_at > now())
    LIMIT 1`)[0]??null}async function R(e){let t=await (0,i.requireAuth)(e);if(t){let e=await r.sql`
      SELECT id FROM workspaces WHERE user_id = ${t.user.id}
      ORDER BY created_at LIMIT 1`;if(e[0])return e[0].id}return null}async function N(e,t,a,r,i,o=0){let d=o>0?Math.ceil(o/4):0,p=await c(e);if(p<5)throw new s(p);let _=(0,n.newRequestId)(),k=Date.now(),E=(t,a,i)=>(0,n.logReq)({reqId:_,workspaceId:e,endpoint:r.endpointType,latencyMs:Date.now()-k,status:t,ok:a,note:i}),f="",x=0,T="stop",y=1e3*Math.floor(p/t);if(d>y)throw new s(p);await a((e,t,a,r)=>{if(t)a&&(x=Math.max(a.totalTokens,d+a.completionTokens)),("length"===r||"MAX_TOKENS"===r)&&(T="length");else if(f+=e,(x=d+Math.ceil(f.length/4))>y)throw T="token_exhausted",Error("TOKEN_EXHAUSTED")},i).catch(e=>{if(!(e instanceof Error)||"TOKEN_EXHAUSTED"!==e.message){if(i.aborted){T="aborted";return}throw e}}),0===x&&(x=d);let R=x||0,$=Math.ceil(R/1e3*t);if($>0){let t=await l(e,$);if(!t)throw await u(e);await w(e,$,r,t.ledgerId),E(200,!0)}else E(200,!0);return{totalTokens:R,finishReason:T,reply:f}}e.s(["InsufficientKeyQuotaError",0,f,"InsufficientTokensError",0,s,"chatCost",0,function(e){return/pro|120b/i.test(e)?10:1},"extendedExpiry",0,function(){return r.sql`LEAST(
    GREATEST(COALESCE(expires_at, now()), now()) + make_interval(days => ${7}),
    now() + make_interval(days => ${30})
  )`},"imageCost",0,function(e){return"nano-banana-pro"===e?50:3},"insufficient",0,function(e,t="chat"){let r="number"==typeof e?{balance:e,expired:!1}:e,n=d(r);return a.NextResponse.json({error:{code:r.expired?"WORKSPACE_EXPIRED":"INSUFFICIENT_TOKENS",message:n},gatekeeper:{decision:"BLOCK",service:t,category:"credit",risk_level:"low",reason:r.expired?"Masa aktif workspace sudah lewat.":"Saldo workspace tidak mencukupi biaya permintaan.",user_message:n}},{status:402})},"insufficientMessage",0,d,"validateApiKey",0,y,"videoCost",0,function(e){return"veo-3.1-quality"===e?200:5},"withKeyTokens",0,T,"withTokens",0,E,"withTokensStream",0,N,"workspaceIdForRequest",0,R])},40766,e=>{"use strict";async function t(e,t){var a;let r;try{r=await fetch(e,t)}catch{return await fetch(e,t)}return!r.ok&&(a=r.status)>=500&&a<=599&&(r=await fetch(e,t)),r}e.s(["fetchRetryOnce",0,t,"logReq",0,function(e){console.log(JSON.stringify({t:"req",ts:new Date().toISOString(),reqId:e.reqId,ws:e.workspaceId??void 0,endpoint:e.endpoint,latencyMs:e.latencyMs,status:e.status,ok:e.ok,note:e.note}))},"newRequestId",0,function(){try{return crypto.randomUUID()}catch{return`${Date.now()}-${Math.floor(1e9*Math.random())}`}}])},38339,e=>{"use strict";var t=e.i(63955);let a=new Map,r=!1;function n(e,t,r){let n=Math.floor(Date.now()/(1e3*r)),i=a.get(e);return i&&i.window===n?(i.count+=1,i.count>t):(a.set(e,{count:1,window:n}),!1)}async function i(e,a=60,s=60){if(!process.env.REDIS_URL)return n(e,a,s);let o=Math.floor(Date.now()/(1e3*s));try{let r=await t.redis.incr(`rl:${e}:${o}`);return 1===r&&await t.redis.expire(`rl:${e}:${o}`,s+5),r>a}catch{return r||(r=!0,console.warn("[rate-limit] Redis down, fallback in-memory.")),n(e,a,s)}}e.s(["rateLimited",0,i,"retryAfterSec",0,function(e=60){let t=Date.now();return Math.ceil(((Math.floor(t/(1e3*e))+1)*e*1e3-t)/1e3)}])},82962,e=>{"use strict";var t=e.i(62294);async function a(e){return await t.sql.begin(async t=>{let a=await t`
      UPDATE receipts SET refunded_at = now()
      WHERE is_claimed IS NOT TRUE AND refunded_at IS NULL
        AND expires_at IS NOT NULL AND expires_at <= now()
        AND cafe_id IS NOT NULL
        AND (${e??null}::uuid IS NULL OR cafe_id = ${e??null}::uuid)
      RETURNING id, cafe_id, tokens_granted, code`,r=0;for(let e of a){let a=await t`
        UPDATE cafes SET prepaid_token_balance = prepaid_token_balance + ${e.tokens_granted}
        WHERE id = ${e.cafe_id}
        RETURNING prepaid_token_balance`;a[0]&&(await t`
        INSERT INTO cafe_token_transactions (cafe_id, type, amount, balance_after, reference_type, reference_id, note)
        VALUES (${e.cafe_id}, 'refund', ${e.tokens_granted}, ${a[0].prepaid_token_balance}, 'receipt', ${e.id},
                ${`Struk ${e.code} kedaluwarsa (tidak diklaim 7 hari)`})`,r+=e.tokens_granted)}return r})}e.s(["RECEIPT_VALID_DAYS",0,7,"receiptStatus",0,function(e){return e.is_claimed?"claimed":e.refunded_at||e.expires_at&&new Date(e.expires_at).getTime()<=Date.now()?"expired":"unclaimed"},"sweepExpiredReceipts",0,a])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0osrg6p._.js.map