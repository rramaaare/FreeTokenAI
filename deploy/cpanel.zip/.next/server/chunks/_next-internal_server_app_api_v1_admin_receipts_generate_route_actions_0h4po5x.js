module.exports=[55396,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_receipts_generate_route_actions_0h4po5x.js.map