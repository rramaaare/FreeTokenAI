globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/1bGk3fA7lwAWea5o72v3P/_buildManifest.js",
    "static/1bGk3fA7lwAWea5o72v3P/_ssgManifest.js",
    "static/1bGk3fA7lwAWea5o72v3P/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3yfl9fgvivx3-.js",
    "static/chunks/2i51e627rllld.js",
    "static/chunks/196x_tfexoucg.js",
    "static/chunks/3ertolydtjaa3.js",
    "static/chunks/turbopack-1w7vl2t-ujijb.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
