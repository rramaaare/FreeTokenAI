var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__1cf4pve._.js")
R.c("server/chunks/[root-of-the-server]__00ntari._.js")
R.m(62395)
module.exports=R.m(62395).exports
