var R=require("../../chunks/[turbopack]_runtime.js")("server/app/healthz/route.js")
R.c("server/chunks/[root-of-the-server]__1zkllop._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__0ubeh_0._.js")
R.c("server/chunks/_next-internal_server_app_healthz_route_actions_15-b67g.js")
R.m(27705)
module.exports=R.m(27705).exports
