var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/media/asset/[id]/route.js")
R.c("server/chunks/_05da736._.js")
R.c("server/chunks/[root-of-the-server]__1eoby99._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/_next-internal_server_app_api_media_asset_[id]_route_actions_1bytwu4.js")
R.m(55077)
module.exports=R.m(55077).exports
