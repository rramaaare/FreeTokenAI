var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/generations/route.js")
R.c("server/chunks/[root-of-the-server]__0rv5fyo._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_generations_route_actions_0nf_tg0.js")
R.m(81620)
module.exports=R.m(81620).exports
