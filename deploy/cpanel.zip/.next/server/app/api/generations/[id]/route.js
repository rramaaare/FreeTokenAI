var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/generations/[id]/route.js")
R.c("server/chunks/_1lkwdsv._.js")
R.c("server/chunks/[root-of-the-server]__0_-3yjo._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/_next-internal_server_app_api_generations_[id]_route_actions_0czhss4.js")
R.m(88392)
module.exports=R.m(88392).exports
