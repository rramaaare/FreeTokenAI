var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/workspace/route.js")
R.c("server/chunks/[root-of-the-server]__1cy2g1b._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_workspace_route_actions_1v_mr4x.js")
R.m(18255)
module.exports=R.m(18255).exports
