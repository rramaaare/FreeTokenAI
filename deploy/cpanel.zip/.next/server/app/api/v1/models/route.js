var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/models/route.js")
R.c("server/chunks/[root-of-the-server]__1ffwoom._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_models_route_actions_0jrirco.js")
R.m(41800)
module.exports=R.m(41800).exports
