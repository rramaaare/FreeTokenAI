var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/usage-logs/[id]/rating/route.js")
R.c("server/chunks/[root-of-the-server]__0pxzf9v._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_usage-logs_[id]_rating_route_actions_1tmn7l2.js")
R.m(86271)
module.exports=R.m(86271).exports
