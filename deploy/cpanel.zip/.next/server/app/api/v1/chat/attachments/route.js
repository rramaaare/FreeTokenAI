var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/chat/attachments/route.js")
R.c("server/chunks/[root-of-the-server]__0c-u584._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0nbfgvz._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_chat_attachments_route_actions_0gq474s.js")
R.m(54459)
module.exports=R.m(54459).exports
