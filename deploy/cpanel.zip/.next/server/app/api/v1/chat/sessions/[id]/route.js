var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/chat/sessions/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1upfpm6._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_chat_sessions_[id]_route_actions_0gq8_x0.js")
R.m(85481)
module.exports=R.m(85481).exports
