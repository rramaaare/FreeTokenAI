var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/chat/sessions/[id]/messages/route.js")
R.c("server/chunks/[root-of-the-server]__18r5_7x._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_v1_chat_sessions_[id]_messages_route_actions_20fnjrf.js")
R.m(48652)
module.exports=R.m(48652).exports
