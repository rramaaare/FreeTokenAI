var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__1uceh2i._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_auth_me_route_actions_0opdztq.js")
R.m(25251)
module.exports=R.m(25251).exports
