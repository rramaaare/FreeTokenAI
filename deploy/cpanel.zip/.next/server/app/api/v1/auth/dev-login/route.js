var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/auth/dev-login/route.js")
R.c("server/chunks/[root-of-the-server]__16y1-m1._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_auth_dev-login_route_actions_1b-goo9.js")
R.m(16475)
module.exports=R.m(16475).exports
