var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/user/balance/route.js")
R.c("server/chunks/[root-of-the-server]__16zg_29._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_user_balance_route_actions_1-1w6ax.js")
R.m(25142)
module.exports=R.m(25142).exports
