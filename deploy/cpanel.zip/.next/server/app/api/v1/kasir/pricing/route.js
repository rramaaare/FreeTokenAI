var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/kasir/pricing/route.js")
R.c("server/chunks/[root-of-the-server]__1ox-6pb._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_kasir_pricing_route_actions_1j0ora3.js")
R.m(84135)
module.exports=R.m(84135).exports
