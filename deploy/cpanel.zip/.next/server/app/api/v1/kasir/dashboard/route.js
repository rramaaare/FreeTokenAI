var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/kasir/dashboard/route.js")
R.c("server/chunks/[root-of-the-server]__0g1p62p._.js")
R.c("server/chunks/_1l4gv1o._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_kasir_dashboard_route_actions_0hb95gt.js")
R.m(14555)
module.exports=R.m(14555).exports
