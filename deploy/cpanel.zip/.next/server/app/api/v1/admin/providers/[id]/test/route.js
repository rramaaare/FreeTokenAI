var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/providers/[id]/test/route.js")
R.c("server/chunks/[root-of-the-server]__05wv4hs._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_providers_[id]_test_route_actions_1il8r_b.js")
R.m(47520)
module.exports=R.m(47520).exports
