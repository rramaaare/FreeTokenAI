var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__1rqtr-t._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_auth_logout_route_actions_1oaz2jj.js")
R.m(28607)
module.exports=R.m(28607).exports
