var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/receipts/lookup/route.js")
R.c("server/chunks/[root-of-the-server]__0ev2wor._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_receipts_lookup_route_actions_0zftvrg.js")
R.m(24114)
module.exports=R.m(24114).exports
