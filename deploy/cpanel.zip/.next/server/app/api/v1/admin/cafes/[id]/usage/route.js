var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/cafes/[id]/usage/route.js")
R.c("server/chunks/[root-of-the-server]__0y6-ds6._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_cafes_[id]_usage_route_actions_05h19-1.js")
R.m(84048)
module.exports=R.m(84048).exports
