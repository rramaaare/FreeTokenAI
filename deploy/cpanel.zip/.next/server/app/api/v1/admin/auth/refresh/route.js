var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/auth/refresh/route.js")
R.c("server/chunks/[root-of-the-server]__0_lbh_v._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_auth_refresh_route_actions_19z-j-8.js")
R.m(40410)
module.exports=R.m(40410).exports
