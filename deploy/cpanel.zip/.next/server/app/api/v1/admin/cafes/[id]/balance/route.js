var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/cafes/[id]/balance/route.js")
R.c("server/chunks/[root-of-the-server]__0y6--1q._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_cafes_[id]_balance_route_actions_1ggx893.js")
R.m(55290)
module.exports=R.m(55290).exports
