var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/receipts/generate/route.js")
R.c("server/chunks/[root-of-the-server]__0f-lhtz._.js")
R.c("server/chunks/_0y9j423._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_receipts_generate_route_actions_0h4po5x.js")
R.m(12397)
module.exports=R.m(12397).exports
