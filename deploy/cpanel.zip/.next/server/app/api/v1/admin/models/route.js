var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/models/route.js")
R.c("server/chunks/[root-of-the-server]__1gi-p80._.js")
R.c("server/chunks/_032uj77._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_models_route_actions_1al8ltn.js")
R.m(98462)
module.exports=R.m(98462).exports
