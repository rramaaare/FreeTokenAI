var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/token-packages/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1sn3gui._.js")
R.c("server/chunks/_1xjg5kh._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_token-packages_[id]_route_actions_0paczz4.js")
R.m(21664)
module.exports=R.m(21664).exports
