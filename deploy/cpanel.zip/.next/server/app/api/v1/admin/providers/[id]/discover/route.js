var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/providers/[id]/discover/route.js")
R.c("server/chunks/[root-of-the-server]__0295pgd._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_v1_admin_providers_[id]_discover_route_actions_0yvafli.js")
R.m(30424)
module.exports=R.m(30424).exports
