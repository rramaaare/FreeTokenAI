var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/users/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1sn3gui._.js")
R.c("server/chunks/_18zfzj1._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_users_[id]_route_actions_04t6q1a.js")
R.m(69165)
module.exports=R.m(69165).exports
