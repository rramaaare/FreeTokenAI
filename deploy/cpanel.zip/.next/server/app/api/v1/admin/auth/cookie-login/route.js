var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/auth/cookie-login/route.js")
R.c("server/chunks/[root-of-the-server]__0zyl2zb._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__0ubeh_0._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_auth_cookie-login_route_actions_0bjzhzd.js")
R.m(90037)
module.exports=R.m(90037).exports
