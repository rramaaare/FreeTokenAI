var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__01_do__._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_auth_login_route_actions_11446ry.js")
R.m(16597)
module.exports=R.m(16597).exports
