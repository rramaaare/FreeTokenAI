var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/cafes/[id]/static-qr.png/route.js")
R.c("server/chunks/[root-of-the-server]__0ex9jif._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/[root-of-the-server]__06fdld3._.js")
R.c("server/chunks/1oeh_server_app_api_v1_admin_cafes_[id]_static-qr_png_route_actions_2004prx.js")
R.m(27546)
module.exports=R.m(27546).exports
