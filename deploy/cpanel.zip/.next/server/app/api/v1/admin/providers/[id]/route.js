var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/providers/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1gi-p80._.js")
R.c("server/chunks/_06n_m34._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_providers_[id]_route_actions_11qvg6-.js")
R.m(52704)
module.exports=R.m(52704).exports
