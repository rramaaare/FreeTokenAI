var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/cafes/route.js")
R.c("server/chunks/[root-of-the-server]__0g1p62p._.js")
R.c("server/chunks/_06ata4j._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_cafes_route_actions_1vst9-b.js")
R.m(49542)
module.exports=R.m(49542).exports
