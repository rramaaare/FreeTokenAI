var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/cafe-topup-requests/route.js")
R.c("server/chunks/[root-of-the-server]__1sn3gui._.js")
R.c("server/chunks/_0ho-f70._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_cafe-topup-requests_route_actions_1djok62.js")
R.m(75066)
module.exports=R.m(75066).exports
