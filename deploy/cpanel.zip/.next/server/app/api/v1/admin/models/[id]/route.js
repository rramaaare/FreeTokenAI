var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/models/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1gkehb-._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_models_[id]_route_actions_02w4a5-.js")
R.m(37676)
module.exports=R.m(37676).exports
