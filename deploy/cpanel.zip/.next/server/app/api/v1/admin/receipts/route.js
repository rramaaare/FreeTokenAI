var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/receipts/route.js")
R.c("server/chunks/[root-of-the-server]__1sxq9el._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_receipts_route_actions_0ykgrqg.js")
R.m(43754)
module.exports=R.m(43754).exports
