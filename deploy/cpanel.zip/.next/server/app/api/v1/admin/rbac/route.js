var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/admin/rbac/route.js")
R.c("server/chunks/[root-of-the-server]__0o1849k._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_admin_rbac_route_actions_161jj16.js")
R.m(59775)
module.exports=R.m(59775).exports
