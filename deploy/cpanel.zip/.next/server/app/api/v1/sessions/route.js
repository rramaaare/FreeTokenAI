var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/sessions/route.js")
R.c("server/chunks/[root-of-the-server]__13t-xdj._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_sessions_route_actions_1ua9n6z.js")
R.m(40275)
module.exports=R.m(40275).exports
