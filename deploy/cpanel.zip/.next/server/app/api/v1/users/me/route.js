var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/users/me/route.js")
R.c("server/chunks/[root-of-the-server]__211gh-a._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_users_me_route_actions_1jcnw75.js")
R.m(54964)
module.exports=R.m(54964).exports
