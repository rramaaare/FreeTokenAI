var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/users/profile/route.js")
R.c("server/chunks/[root-of-the-server]__1yw8uf1._.js")
R.c("server/chunks/_14ra4y5._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/lib_db_ts_1ttuckb._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_users_profile_route_actions_1_kpknu.js")
R.m(54311)
module.exports=R.m(54311).exports
